/**
 * Esta clase mantiene informaci�n sobre un libro.
 * Podr�a formar parte de una aplicaci�n m�s grande como un sistema que gestionase una librer�a, por ejemplo.
 *
 * @author (Introduce tu nombre)
 * @version (Inserta la fecha de hoy)
 */
class Libro
{
    // los atributos
    private String autor;
    private String titulo;

    /**
     * establecer el autor y el t�tulo cunado el objeto se construya
     */
    public Libro(String queAutor, String queTitulo)
    {
        autor = queAutor;
        titulo = queTitulo;
    }

    // A�adir los m�todos ...
}
