
/**
 * Escriba la descripci�n de la clase FacturaLuz aqu�.
 * La clase guarada inforamci�n acerca del consumo de luz efectuado 
 * @author (su nombre) 
 * @version (n� versi�n o fecha)
 */
public class FacturaLuz
{
    // consumo en el inicio del per�odo a facturar
    private int lecturaAnterior;
    // consumo al final del per�odo a facturar
    private int lecturaActual;

    /**
     * Constructor de la clase FacturaLuz
     */
    public FacturaLuz()
    {

    }   
}
