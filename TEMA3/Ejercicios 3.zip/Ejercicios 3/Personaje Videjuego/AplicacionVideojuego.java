
/**
 * Escribe la descripci�n de la clase AplicacionVideojuego aqu�.
 * 
 * @author (tu nombre) 
 * @version (n� versi�n o fecha)
 */
public class AplicacionVideojuego
{
        public static void main (String args[])
        {
                 InterfazUsuario interfaz = new InterfazUsuario();
                 interfaz.ejecutar();
        }
        
        
        
}
